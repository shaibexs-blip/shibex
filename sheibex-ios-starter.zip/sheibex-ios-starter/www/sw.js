/* Minimal compatibility service worker for the existing HTML's registration hook.
   Capacitor packages the local web assets with the app; this worker intentionally
   does not cache accounting data or intercept requests. */
self.addEventListener('install', function (event) { self.skipWaiting(); });
self.addEventListener('activate', function (event) { event.waitUntil(self.clients.claim()); });
